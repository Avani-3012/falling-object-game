var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c23e590b-7b9e-4ccf-8149-1c848a8c18ef","8a065287-b7d3-4dc5-9ee3-5664c98627d3","5885705c-725b-40ab-91db-fb1fcceb33dc"],"propsByKey":{"c23e590b-7b9e-4ccf-8149-1c848a8c18ef":{"name":"ice_cream_1","sourceUrl":"assets/api/v1/animation-library/gamelab/ewv1CoVpLikMCrFTr6w.v_kIjO9ZuAIY/category_food/ice_cream.png","frameSize":{"x":146,"y":300},"frameCount":1,"looping":true,"frameDelay":2,"version":"ewv1CoVpLikMCrFTr6w.v_kIjO9ZuAIY","loadedFromSource":true,"saved":true,"sourceSize":{"x":146,"y":300},"rootRelativePath":"assets/api/v1/animation-library/gamelab/ewv1CoVpLikMCrFTr6w.v_kIjO9ZuAIY/category_food/ice_cream.png"},"8a065287-b7d3-4dc5-9ee3-5664c98627d3":{"name":"pizza_slice_1","sourceUrl":"assets/api/v1/animation-library/gamelab/iOS_nMvxJd1wwEe8Ca9C9ce9gjlyc7ON/category_food/pizza_slice.png","frameSize":{"x":300,"y":200},"frameCount":1,"looping":true,"frameDelay":2,"version":"iOS_nMvxJd1wwEe8Ca9C9ce9gjlyc7ON","loadedFromSource":true,"saved":true,"sourceSize":{"x":300,"y":200},"rootRelativePath":"assets/api/v1/animation-library/gamelab/iOS_nMvxJd1wwEe8Ca9C9ce9gjlyc7ON/category_food/pizza_slice.png"},"5885705c-725b-40ab-91db-fb1fcceb33dc":{"name":"sci_fi_1","sourceUrl":"assets/api/v1/animation-library/gamelab/6R1r6_thyaqHGORcm3JlEVMzjsWX0mFI/category_backgrounds/background_scifi.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"6R1r6_thyaqHGORcm3JlEVMzjsWX0mFI","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/6R1r6_thyaqHGORcm3JlEVMzjsWX0mFI/category_backgrounds/background_scifi.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

// CREATE BACKGROUND
var bg = createSprite(0, 0 ,400, 400);
bg.setAnimation("sci_fi_1");
bg.scale = 2.5;
bg.y = bg.height/2;
 var coin;
 var coin1;
//DECLARE COUNTs
var count = 0;
var timer = 0;

//CREATE GROUPS
var cg = createGroup();
var cg1 = createGroup();

//DECLARE GAMESTATES


function draw() {
  //APPLY BACKGROUND
  background("white");
  
  // INCREASE COUNT
 
   //ROUND THE NUMBER TO NEAREST DIGIT
   //count1 = Math.round(World.frameCount / 10);
   
   if (World.frameCount%155 ===0) {
     timer = timer + 1;
   }
   
  if (mousePressedOver(coin)) {
      count = count + 1;
      coin.destroy();
      playSound("assets/category_bell/notification_4.mp3");
       
    }
   if (mousePressedOver(coin1)) {
      count = count + 1;
      coin1.destroy();
      playSound("assets/category_bell/long_bell_notification.mp3");
    }
 
  //DISPLAY TEXT
  drawSprites();
  textSize(25);
  fill("blue");
  text("SCORE:"+count, 10, 130);
  text("Timer:" + timer+"/200", 10, 100);
  
  
  
  //CREATE FUNCTIONS
  func();
  func1();
}


function func() {
  if (World.frameCount%100 ===0) {
    
    // DECLARE COIN
    coin = createSprite(50, 0, 10, 10);
    coin.setAnimation("ice_cream_1");
    
    // X POSITION OF COIN
    coin.x = randomNumber(0, 400);
    
    //SET COIN VELOCITY
    coin.velocityY = 2;
    
    //SET THE SIZE OF COIN
    coin.scale = 0.21;
    
    //SET THE LIFETIME OF COIN
    coin.lifetime = 390;
    
    // ADD COIN TO CG GROUP
    cg.add(coin);
  }
}
function func1() {
  
  if (World.frameCount%100 ===0) {
    
    //DECLARE COIN1
    coin1 = createSprite(350, 0, 10, 10);
    coin1.setAnimation("pizza_slice_1");
    
    //SET X POSITION OF COIN1
    coin1.x = randomNumber(0, 400);
    
    //SET VELOCITY OF COIN1
    coin1.velocityY = 2;
    
    //SET THE SIZE OF COIN1
    coin1.scale = 0.21;
    
    //SET THE LIFETIME OF COIN1
    coin1.lifetime = 390;
    
    //ADD COIN1 TO CG1 GROUP
    cg1.add(coin1);
  }
}
  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
